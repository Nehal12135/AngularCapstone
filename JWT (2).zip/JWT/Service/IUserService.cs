﻿namespace JWT.Service
{
    public interface IUserService
    
     {
        string GetByName();

    }
}