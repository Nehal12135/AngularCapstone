﻿namespace JWT.helperAppSettings
{
    public class helperAppSettings
    {
        public string Secret { get; set; }
    }
}
