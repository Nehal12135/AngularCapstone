﻿using JWT.Models;
using JWT.Repo;
using JWT.Service;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc; 
using Microsoft.IdentityModel.Tokens;
using System.IdentityModel.Tokens.Jwt;
using System.Security.Claims;
using System.Security.Cryptography;

namespace JWT.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class AuthController : ControllerBase
    {
        public static Register register = new Register();

        public static Login login = new Login();

        private readonly IConfiguration _configuration;
        private readonly IAuth _userService;

        private readonly IPasswordHasher _passwordHasher;

        private readonly IHttpContextAccessor _cxtAccessor;
        private readonly CustomDbContext _customDbContext;

        private readonly IRepo _repo;

        public AuthController(IConfiguration configuration, IHttpContextAccessor cxtAccessor, CustomDbContext customDbContext
            , IRepo repo,IPasswordHasher passwordHasher,IAuth auth)
        {
            _configuration = configuration;
            _userService = auth;
            _cxtAccessor = cxtAccessor;
            _customDbContext = customDbContext;
            _passwordHasher = passwordHasher;
            _repo = repo;
            this._customDbContext = _customDbContext;
        }



        [AllowAnonymous]
        [HttpPost]
        [Route("register")]
        public async Task<IActionResult> Signup([FromBody] Register reg)
        {
            _customDbContext.BuildConnectionstring(_configuration.GetConnectionString("registerConn"));
            var status = _repo.createCustomers(reg);

            if (status == "OK")
            {
                return Ok(new { message = "customer created successfully!" });
            }
            else
            {
                return StatusCode(429, status);
            }
        }


            //login

            [AllowAnonymous]
            [Route("login")]
            [HttpPost]
            public IActionResult LoginCheck([FromBody] Login login)
            {


                _customDbContext.BuildConnectionstring(_configuration.GetConnectionString("registerConn"));

                var user = _customDbContext.UserReg.FirstOrDefault(u => u.UserName == login.UserName);
                if (user == null || !_passwordHasher.VerifyIdentityV3Hash(login.Password, user.Password)) return BadRequest(new { message = "Invalid - Username or password" });

                var jwtToken = _userService.GenerateToken(user.UserName, user.Password);



                if (jwtToken == null)
                    return BadRequest(new { message = "Invalid Credentials" });

                return Ok(jwtToken);
            }
        }










            /* [HttpGet, Authorize]
             public ActionResult<string> GetMe()
             {
                 var UserName = _userService.GetByName();
                 return Ok(UserName);
             }*/


            /*  [AllowAnonymous]
              [HttpPost]
              [Route("signup")]
              public async Task<IActionResult> Signup([FromBody] Register value)
              {


                  _customDbContext.BuildConnectionstring(_configuration.GetConnectionString("registerConn"));

                  var user = _customDbContext.UserReg.SingleOrDefault(u => u.UserName == value.UserName);
                  if (user != null) return StatusCode(409);

                  _customDbContext.UserReg.Add(new Register 
                  {
                      UserName = value.UserName,
                      Email=value.Email,
                      Phone= value.Phone,
                      Password= value.Password

                  });


                  await _customDbContext.SaveChangesAsync();
                  //user = _customDbContext.Users.SingleOrDefault(u => u.username == value.username);
                  return Ok(new { message = "Account Created! Please Login..." });
              }*/

















            /*
                    [HttpPost("register")]
                    public async Task<ActionResult<Register>> Register(Login request)
                    {
                        CreatePasswordHash(request.Password, out byte[] passwordHash, out byte[] passwordSalt);

                        register.UserName = request.UserName;
                        register.passwordhash = passwordHash;
                        register.passwordsalt = passwordSalt;
                        return Ok(register);
                    }







                    [HttpPost("login")]

                    public async Task<ActionResult<string>> Login(Login request)
                    {
                        if (register.UserName != request.UserName)
                        {
                            return BadRequest("Invalid user");

                        }



                        string token = CreateToken(register);



                        return Ok(token);
                    }







                    private string CreateToken(Register register)
                    {
                        List<Claim> claims = new List<Claim>
                        {
                            new Claim(ClaimTypes.Name,register.UserName)
                        };
                        var key = new SymmetricSecurityKey(System.Text.Encoding.UTF8.GetBytes(_configuration.GetSection("Jwt:Key").Value));
                        var cred = new SigningCredentials(key, SecurityAlgorithms.HmacSha256Signature);

                        var token = new JwtSecurityToken(claims: claims, expires: DateTime.Now.AddMinutes(15), signingCredentials: cred);

                        var jwt = new JwtSecurityTokenHandler().WriteToken(token);
                        return jwt;
                    }



                    private void CreatePasswordHash(string password, out byte[] passwordHash, out byte[] passwordSalt)
                    {
                        using (var hmac = new HMACSHA512())
                        {
                            passwordSalt = hmac.Key;
                            passwordHash = hmac.ComputeHash(System.Text.Encoding.UTF8.GetBytes(password));
                        }
                    }*/
        }
    