﻿using Microsoft.Extensions.Options;
using Microsoft.IdentityModel.Tokens;
using System.IdentityModel.Tokens.Jwt;
using System.Security.Claims;
using System.Text;

namespace JWT.Models
{
    public class AuthService:IAuth
    {

        private readonly IHttpContextAccessor httpContextAccessor;
        private readonly IConfiguration _configuration;
        public AuthService(IHttpContextAccessor httpContextAccessor, IConfiguration configuration)
        {

            this.httpContextAccessor = httpContextAccessor;
            _configuration = configuration;
        }
        public SecurityTokeModel GenerateToken(string UserName, string Password)
        {
            var tokenHandler = new JwtSecurityTokenHandler();
            var key = Encoding.ASCII.GetBytes(_configuration.GetSection("Jwt").GetSection("key").Value);
            var sk = new SymmetricSecurityKey(key);
            var tokenDescriptor = new SecurityTokenDescriptor
            {
                Issuer = "http://ScoriaIT/mainsubsys",
                Audience = "http://ScoriaIT/subsys",
                Subject = new ClaimsIdentity(new Claim[]
                    {
                        new Claim(JwtRegisteredClaimNames.Sub, $"{UserName}"),
                new Claim(JwtRegisteredClaimNames.Iat, DateTime.UtcNow.ToUniversalTime().ToString(),
                    ClaimValueTypes.Integer64),
                    new Claim("accountnumber", UserName),
                    new Claim("currency", "$"),
                    new Claim("name", UserName),
                    new Claim(ClaimTypes.NameIdentifier, UserName)
                    }),
                Expires = DateTime.Now.AddMinutes(60),

                SigningCredentials = new SigningCredentials(sk, SecurityAlgorithms.HmacSha256Signature)
            };

            var token = tokenHandler.CreateToken(tokenDescriptor);


            var jwtSecurityToken = tokenHandler.WriteToken(token);


            //var jwtSecurityToken =new JwtSecurityTokenHandler().WriteToken(token)            
            // jwtSecurityToken. token.ValidTo;

            return new Models.SecurityTokeModel() { auth_token = jwtSecurityToken };
        }
    }
}