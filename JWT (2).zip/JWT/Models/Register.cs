﻿namespace JWT.Models
{
    public class Register
    {
        public string? UserName { get; set; }

        public string? Email { get; set; }

        public string? Phone { get; set; }

        public string? Password { get; set; }

        /*public string? appcode { get; set; }
        public byte[] passwordhash { get; set; }
        public byte[] passwordsalt { get; set; }*/
    }
}