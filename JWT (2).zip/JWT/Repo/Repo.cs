﻿using JWT.Models;

namespace JWT.Repo
{
    public class Repo : IRepo
    {
        private readonly CustomDbContext _customDbContext;
        private readonly Models.IPasswordHasher _passwordHasher;

        public Repo(CustomDbContext c ,  IPasswordHasher passwordHasher)
        {
            _customDbContext = c;
            _passwordHasher = passwordHasher;
        }
        public string createCustomers(Register register)
        {
            _customDbContext.UserReg.Add(new usermodels
            {
               UserName=register.UserName,
               Email=register.Email,
               Phone=register.Phone,
               Password= _passwordHasher.GenerateIdentityV3Hash(register.Password)
            });
            _customDbContext.SaveChanges();
            return "OK";
        }


    }
}
