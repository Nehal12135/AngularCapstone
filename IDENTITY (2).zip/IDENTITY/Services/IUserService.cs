﻿namespace IDENTITY.Services
{
    public interface IUserService
    {
        public string GetbyName();
    }
}
