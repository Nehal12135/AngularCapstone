﻿using IDENTITY.Models;
using IDENTITY.Services;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.IdentityModel.Tokens;
using System.IdentityModel.Tokens.Jwt;
using System.Security.Claims;
using System.Security.Cryptography;

namespace IDENTITY.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class AuthController : ControllerBase
    {
        public static Register register = new Register();

        private readonly IConfiguration _configuration;
        private readonly IUserService _userService;

        public AuthController(IConfiguration configuration,IUserService userService)
        {
            _configuration = configuration;
            _userService = userService;
        }


        [HttpGet, Authorize]
        public ActionResult<string> GetMe()
        {
            var UserName = _userService.GetbyName();
            return Ok(UserName);
        }


        [HttpPost("register")]
        public async Task<ActionResult<Register>> Register(Login request)        
        {
            CreatePasswordHash(request.Password, out byte[] passwordHash,out byte[] passwordSalt);

            register.UserName= request.UserName;
            register.PasswordHash = passwordHash;
            register.PasswordSalt = passwordSalt;
            return Ok(register);
        }

        [HttpPost("login")]

        public async Task<ActionResult<string>>Login(Login request)
        {
            if (register.UserName != request.UserName)
            {
                return BadRequest("Error");

            }

            

            string token = CreateToken(register);

            

            return Ok(token);
        }


        private string CreateToken(Register register)
        {
            List<Claim> claims = new List<Claim>
            {
                new Claim(ClaimTypes.Name,register.UserName)
            };
            var key = new SymmetricSecurityKey(System.Text.Encoding.UTF8.GetBytes(_configuration.GetSection("AppSettings:Token").Value));
            var cred = new SigningCredentials(key, SecurityAlgorithms.HmacSha256Signature);

            var token = new JwtSecurityToken(claims: claims, expires: DateTime.Now.AddMinutes(1), signingCredentials: cred);

            var jwt = new JwtSecurityTokenHandler().WriteToken(token);
            return jwt;
        }


       
        private void CreatePasswordHash(string Password,out byte[] passwordHash, out byte[] passwordSalt)
        {
            using(var hmac=new HMACSHA512())
            {
                passwordSalt = hmac.Key;
                passwordHash=hmac.ComputeHash(System.Text.Encoding.UTF8.GetBytes(Password));
            }
        }
    }
}
