﻿using PMS.Models;

namespace PMS.Repository
{
    public class Repo:IRepo
    {
        private readonly customdbContext _customdbContext;

        public Repo(customdbContext customdContext)
        {
            _customdbContext = customdContext;
        }


        public IEnumerable<Product> getproducts()
        {
            return _customdbContext.Products;
        }

        public string createproduct(Product p)
        {
            _customdbContext.Products.Add(p);
            _customdbContext.SaveChanges();
            return "OK";
        }

        public IEnumerable<Cart> getcartlist()
        {
            return _customdbContext.Cart;
        }


        public string addcart(Cart cart)
        {
            _customdbContext.Cart.Add(cart);
            _customdbContext.SaveChanges();
            return "OK";
        }

    }
}