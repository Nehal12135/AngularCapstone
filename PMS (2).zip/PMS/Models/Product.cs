﻿using System.ComponentModel.DataAnnotations;

namespace PMS.Models
{
    public class Product
    {
        [Key]
        public int productID { get; set; }
        public string productName { get; set; }
        public decimal productPrice { get; set; }
        public string imageUrl { get; set; }
    }
}
