﻿namespace PMS.Models
{
    public class Cart
    {
        public int productID { get; set; }
        public string productName { get; set; }
        public decimal productPrice { get; set; }
        public string imageUrl { get; set; }
        public int quantity { get; set; }
        public decimal totalPrice { get; set; }

        public string UserName { get; set; }
    }
}