﻿using Microsoft.EntityFrameworkCore;

namespace PMS.Models
{
    public class customdbContext:DbContext
    {
        public DbSet<Product> Products { get; set; }
        public DbSet<Cart> Cart { get; set; }

        public static string ConnectionStrings
        {
            get;
            set;
        }

        public void BuildConnectionstring(string dbstring) { ConnectionStrings = dbstring; }

        public customdbContext(DbContextOptions<customdbContext> options) : base(options)
        {

        }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.Entity<Product>(eb =>
            {
                eb.HasKey("productID");
            });

            modelBuilder.Entity<Cart>(eb =>
            {
                eb.HasKey("productID");
            });
        }

        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            if (!string.IsNullOrEmpty(ConnectionStrings))
            {
                optionsBuilder.UseSqlServer(ConnectionStrings);
            }
        }
    }
}
